<?php
/**
 * Plugin Name: Custom Event Calendar
 * Plugin URI:  https://saratogahotspringsresort.com/
 * Description: A custom events plugin for Saratoga Hot Springs Resort. Manage events with flyers, menus, pricing, and calendar integration.
 * Version:     3.0.0
 * Author:      Cox Group
 * Author URI:  https://saratogahotspringsresort.com/
 * License:     GPL-2.0+
 * Text Domain: custom-event-calendar
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'CEC_VERSION', '3.0.0' );
define( 'CEC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CEC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Load includes
require_once CEC_PLUGIN_DIR . 'includes/post-type.php';
require_once CEC_PLUGIN_DIR . 'includes/meta-boxes.php';
require_once CEC_PLUGIN_DIR . 'includes/shortcode.php';
require_once CEC_PLUGIN_DIR . 'includes/calendar-links.php';
require_once CEC_PLUGIN_DIR . 'includes/template-loader.php';

// Enqueue frontend assets
add_action( 'wp_enqueue_scripts', 'cec_enqueue_assets' );
function cec_enqueue_assets() {
    wp_enqueue_style(
        'cec-style',
        CEC_PLUGIN_URL . 'assets/css/events.css',
        array(),
        CEC_VERSION
    );
    wp_enqueue_script(
        'cec-script',
        CEC_PLUGIN_URL . 'assets/js/events.js',
        array( 'jquery' ),
        CEC_VERSION,
        true
    );
    wp_localize_script( 'cec-script', 'cec_ajax', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'cec_load_more' ),
    ) );

    // jsPDF — only needed on single event pages for the "Download Flyers as PDF" button
    if ( is_singular( 'cec_event' ) ) {
        wp_enqueue_script(
            'jspdf',
            'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js',
            array(),
            '2.5.1',
            true
        );
    }
}

// Enqueue admin assets
add_action( 'admin_enqueue_scripts', 'cec_admin_enqueue_assets' );
function cec_admin_enqueue_assets( $hook ) {
    global $post_type;
    if ( $post_type === 'cec_event' && in_array( $hook, array( 'post.php', 'post-new.php' ) ) ) {
        wp_enqueue_style(
            'cec-admin-style',
            CEC_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            CEC_VERSION
        );
        wp_enqueue_media();
        wp_enqueue_script(
            'cec-admin-script',
            CEC_PLUGIN_URL . 'assets/js/admin.js',
            array( 'jquery' ),
            CEC_VERSION,
            true
        );
    }
}

// Activation
register_activation_hook( __FILE__, 'cec_activate' );
function cec_activate() {
    cec_register_post_type();
    flush_rewrite_rules();
}

// Deactivation
register_deactivation_hook( __FILE__, 'cec_deactivate' );
function cec_deactivate() {
    flush_rewrite_rules();
}
