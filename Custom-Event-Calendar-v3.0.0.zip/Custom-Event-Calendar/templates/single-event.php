<?php
if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

if ( have_posts() ) :
    the_post();

    $post_id    = get_the_ID();
    $start_date = get_post_meta( $post_id, '_cec_start_date', true );
    $start_time = get_post_meta( $post_id, '_cec_start_time', true );
    $end_date   = get_post_meta( $post_id, '_cec_end_date', true );
    $end_time   = get_post_meta( $post_id, '_cec_end_time', true );
    $location   = get_post_meta( $post_id, '_cec_location', true );

    // ── Build unified flyer list ───────────────────────────────
    $all_flyer_ids = array();

    $sidebar_flyer_ids = get_post_meta( $post_id, '_cec_flyer_ids', true );
    if ( is_array( $sidebar_flyer_ids ) ) {
        foreach ( $sidebar_flyer_ids as $fid ) {
            $fid = intval( $fid );
            if ( $fid ) $all_flyer_ids[] = $fid;
        }
    }

    $legacy_flyer_id = intval( get_post_meta( $post_id, '_cec_flyer_id', true ) );
    if ( $legacy_flyer_id && ! in_array( $legacy_flyer_id, $all_flyer_ids ) ) {
        $all_flyer_ids[] = $legacy_flyer_id;
    }

    $extra_flyer_ids = get_post_meta( $post_id, '_cec_extra_flyer_ids', true );
    if ( ! is_array( $extra_flyer_ids ) ) $extra_flyer_ids = array();
    foreach ( $extra_flyer_ids as $fid ) {
        $fid = intval( $fid );
        if ( $fid && ! in_array( $fid, $all_flyer_ids ) ) {
            $all_flyer_ids[] = $fid;
        }
    }

    $flyer_count = count( $all_flyer_ids );

    $pricing_raw = get_post_meta( $post_id, '_cec_pricing_tiers', true );
    $pricing     = ( is_array( $pricing_raw ) && ! empty( $pricing_raw ) ) ? $pricing_raw : array();
    $cal_links   = cec_get_calendar_links( $post_id );
    $thumb       = get_the_post_thumbnail_url( $post_id, 'full' );

    // Share URLs
    $share_url       = get_permalink( $post_id );
    $share_title_raw = get_the_title( $post_id );
    $share_url_enc   = rawurlencode( $share_url );
    $share_title_enc = rawurlencode( $share_title_raw );

    // Format dates
    $date_str = '';
    if ( $start_date ) {
        $date_str = date( 'l, F j, Y', strtotime( $start_date ) );
        if ( $start_time ) $date_str .= ' at ' . date( 'g:i A', strtotime( $start_time ) );
        if ( $end_date && $end_date !== $start_date ) {
            $date_str .= ' – ' . date( 'l, F j, Y', strtotime( $end_date ) );
            if ( $end_time ) $date_str .= ' at ' . date( 'g:i A', strtotime( $end_time ) );
        } elseif ( $end_time ) {
            $date_str .= ' – ' . date( 'g:i A', strtotime( $end_time ) );
        }
    }
?>

<div class="cec-single-wrap">

    <!-- ── Top section: LEFT info (40%) | RIGHT image+text+flyers (60%) ── -->
    <div class="cec-single-top">

        <!-- LEFT: date badge + title + info panels (sticky, unaffected) -->
        <div class="cec-single-top-left">

            <div class="cec-single-event-header">
                <?php if ( $start_date ) : ?>
                <div class="cec-single-header-date">
                    <span class="cec-header-month"><?php echo date( 'M', strtotime( $start_date ) ); ?></span>
                    <span class="cec-header-day"><?php echo date( 'j', strtotime( $start_date ) ); ?></span>
                </div>
                <?php endif; ?>
                <div class="cec-single-header-text">
                    <h1 class="cec-single-title"><?php the_title(); ?></h1>
                </div>
            </div>

            <!-- Date & Time -->
            <?php if ( $date_str ) : ?>
            <div class="cec-info-block">
                <h4><span class="cec-icon">📅</span> Date &amp; Time</h4>
                <p><?php echo esc_html( $date_str ); ?></p>
            </div>
            <?php endif; ?>

            <!-- Location -->
            <?php if ( $location ) : ?>
            <div class="cec-info-block">
                <h4><span class="cec-icon">📍</span> Location</h4>
                <p><?php echo esc_html( $location ); ?></p>
            </div>
            <?php endif; ?>

            <!-- Pricing -->
            <?php if ( ! empty( $pricing ) ) : ?>
            <div class="cec-info-block">
                <h4><span class="cec-icon">🎟️</span> Pricing</h4>
                <ul class="cec-pricing-list">
                    <?php foreach ( $pricing as $tier ) : ?>
                        <li>
                            <span class="cec-tier-label"><?php echo esc_html( $tier['label'] ); ?></span>
                            <span class="cec-tier-price"><?php echo esc_html( $tier['price'] ); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>

            <!-- Add to Calendar -->
            <?php if ( ! empty( $cal_links ) ) : ?>
            <div class="cec-info-block cec-calendar-block">
                <h4><span class="cec-icon">🗓️</span> Add to Calendar</h4>
                <div class="cec-cal-buttons">
                    <a href="<?php echo esc_url( $cal_links['google'] ); ?>" target="_blank" rel="noopener" class="cec-cal-btn cec-cal-google">
                        <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z"/></svg>
                        Google Calendar
                    </a>
                    <a href="<?php echo esc_url( admin_url( 'admin-ajax.php?action=cec_download_ics&event_id=' . $post_id ) ); ?>" class="cec-cal-btn cec-cal-apple">
                        <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98l-.09.06c-.22.15-2.19 1.28-2.17 3.81.03 3.02 2.65 4.03 2.68 4.04l-.06.23zM13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>
                        Apple Calendar
                    </a>
                    <a href="<?php echo esc_url( admin_url( 'admin-ajax.php?action=cec_download_ics&event_id=' . $post_id ) ); ?>" class="cec-cal-btn cec-cal-outlook">
                        <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                        Outlook
                    </a>
                </div>
            </div>
            <?php endif; ?>

            <!-- Share -->
            <div class="cec-share-wrap">
                <button class="cec-share-trigger"
                        data-url="<?php echo esc_attr( $share_url ); ?>"
                        data-title="<?php echo esc_attr( $share_title_raw ); ?>"
                        aria-expanded="false">
                    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
                    Share This Event
                </button>
                <div class="cec-share-popup" hidden>
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $share_url_enc; ?>" target="_blank" rel="noopener" class="cec-share-option">
                        <span class="cec-share-icon cec-share-icon--fb"><svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg></span>
                        Facebook
                    </a>
                    <a href="https://twitter.com/intent/tweet?url=<?php echo $share_url_enc; ?>&text=<?php echo $share_title_enc; ?>" target="_blank" rel="noopener" class="cec-share-option">
                        <span class="cec-share-icon cec-share-icon--x"><svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.737-8.835L1.254 2.25H8.08l4.259 5.629 5.905-5.629zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg></span>
                        Twitter / X
                    </a>
                    <a href="mailto:?subject=<?php echo esc_attr( $share_title_raw ); ?>&body=<?php echo esc_attr( $share_title_raw . "\n\n" . $share_url ); ?>" class="cec-share-option">
                        <span class="cec-share-icon cec-share-icon--email"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><polyline points="2,4 12,13 22,4"/></svg></span>
                        Email
                    </a>
                    <a href="sms:?&body=<?php echo esc_attr( $share_title_raw . ' — ' . $share_url ); ?>" class="cec-share-option">
                        <span class="cec-share-icon cec-share-icon--sms"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></span>
                        Text Message
                    </a>
                    <button class="cec-share-option cec-share-copy-btn" data-url="<?php echo esc_attr( $share_url ); ?>">
                        <span class="cec-share-icon cec-share-icon--copy"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></span>
                        <span class="cec-copy-label">Copy Link</span>
                    </button>
                </div>
            </div>

        </div><!-- .cec-single-top-left -->

        <!-- RIGHT: featured image → description → flyers → download button -->
        <div class="cec-single-top-right">

            <?php if ( $thumb ) : ?>
            <img src="<?php echo esc_url( $thumb ); ?>"
                 alt="<?php echo esc_attr( get_the_title() ); ?>"
                 class="cec-single-hero-img" />
            <?php endif; ?>

            <?php if ( get_the_content() ) : ?>
            <div class="cec-single-right-description">
                <?php the_content(); ?>
            </div>
            <?php endif; ?>

            <!-- Flyers sit directly below the description on the right -->
            <?php if ( ! empty( $all_flyer_ids ) ) : ?>
            <div class="cec-flyers-section">

                <div class="cec-flyers-grid <?php echo $flyer_count === 1 ? 'cec-flyers-single' : 'cec-flyers-multi'; ?>">
                    <?php foreach ( $all_flyer_ids as $fid ) :
                        $furl = wp_get_attachment_url( $fid );
                        if ( ! $furl ) continue;
                    ?>
                    <a href="#"
                       class="cec-flyer-item cec-flyer-lightbox-trigger"
                       data-full-url="<?php echo esc_url( $furl ); ?>"
                       aria-label="View flyer full size">
                        <img src="<?php echo esc_url( $furl ); ?>"
                             alt="<?php echo esc_attr( get_the_title() ); ?> Flyer" />
                    </a>
                    <?php endforeach; ?>
                </div>

                <!-- Download button below the flyers -->
                <div class="cec-download-pdf-wrap">
                    <button id="cec-download-flyers-pdf" class="cec-download-pdf-btn">⬇ Download All Flyers as PDF</button>
                </div>

            </div><!-- .cec-flyers-section -->

            <!-- Lightbox overlay -->
            <div id="cec-lightbox" class="cec-lightbox" style="display:none;" role="dialog" aria-modal="true">
                <div class="cec-lightbox-backdrop"></div>
                <div class="cec-lightbox-container">
                    <button class="cec-lightbox-close" aria-label="Close">&times;</button>
                    <img id="cec-lightbox-img" src="" alt="Flyer" />
                </div>
            </div>

            <?php endif; ?>

        </div><!-- .cec-single-top-right -->

    </div><!-- .cec-single-top -->

    <!-- Back link -->
    <div class="cec-back-link">
        <a href="javascript:history.back()">&larr; Back to Events</a>
    </div>

</div><!-- .cec-single-wrap -->

<?php endif; ?>

<?php get_footer(); ?>
