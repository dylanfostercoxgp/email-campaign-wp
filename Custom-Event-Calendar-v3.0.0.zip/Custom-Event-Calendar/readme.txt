=== Custom Event Calendar ===
Contributors: coxgroup
Tags: events, calendar, custom post type
Requires at least: 5.8
Tested up to: 6.5
Stable tag: 1.0.5
License: GPL-2.0+

A custom events plugin for Saratoga Hot Springs Resort.

== Description ==

Custom Event Calendar allows you to manage and display events on your WordPress site with support for:

- Event dates & times
- Thumbnails and event flyers
- Food & drink menus
- Pricing tiers
- Add to Calendar (Google, Apple, Outlook)
- Automatic hiding of past events
- Events grid shortcode: [events_grid]

== Installation ==

1. Upload the plugin zip via Plugins > Add New > Upload Plugin
2. Activate the plugin
3. Go to Events in your dashboard to add events
4. Add the shortcode [events_grid] to any page

== Changelog ==

= 1.0.5 =
* Changed: Event title color on single event page set to #8f6327
* Changed: Date badge redesigned as a calendar icon square (white card, gold header strip, bold day number)
* Changed: Version stamped consistently across all files

= 1.0.4 =
* Changed: Hero image now uses proportional 1500×720 aspect ratio (no fixed min-height)
* Changed: Event title and date moved below hero image; short description removed from single event page
* Changed: Info cards (Date & Time, Location, Price, etc.) updated with modern sleek design

= 1.0.3 =
* Fixed: Pricing tiers not displaying on event pages (hardened save/retrieve logic)
* Fixed: Subtitle on event cards now truncates at 215 characters with ellipsis
* Changed: Primary event flyer reduced from 680px to 460px max-width

= 1.0.2 =
* Fixed: Pricing rows not clickable/editable in admin (JS was only loading on frontend, now loads correctly in wp-admin)
* Fixed: Additional flyers not appearing on event page (inline JS moved to dedicated admin.js, duplicate prevention added)
* Changed: Primary event flyer moved from sidebar to prominent full-width display in main content area
* Changed: Hero banner height increased from 320px to 460px

= 1.0.1 =
* Fixed: Event content not displaying on single event pages (duplicate the_post() bug)
* Changed: Replaced Food & Drink Menu text field with Additional Flyers image/file uploads
* Added: Additional flyers display as a visual grid on the event page

= 1.0.0 =
* Initial release
