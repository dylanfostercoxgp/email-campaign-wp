/* Custom Event Calendar - Admin JS | Version 1.0.2 | Cox Group */
(function($){
    'use strict';

    $(document).ready(function(){

        // ── Pricing Rows ───────────────────────────────────────
        $('#cec-add-pricing-row').on('click', function(){
            var row = '<div class="cec-pricing-row">' +
                '<input type="text" name="cec_pricing_label[]" placeholder="Label (e.g. General Admission)" />' +
                '<input type="text" name="cec_pricing_price[]" placeholder="Price (e.g. $25)" />' +
                '<button type="button" class="button cec-remove-row">Remove</button>' +
                '</div>';
            $('#cec-pricing-rows').append(row);
        });

        $(document).on('click', '.cec-remove-row', function(){
            $(this).closest('.cec-pricing-row').remove();
        });

        // ── Sidebar Flyers Upload (multiple) ──────────────────
        $('#cec-add-sidebar-flyer').on('click', function(e){
            e.preventDefault();
            var frame = wp.media({
                title: 'Select Event Flyer(s)',
                button: { text: 'Add Flyer(s)' },
                multiple: true
            });
            frame.on('select', function(){
                var attachments = frame.state().get('selection').toJSON();
                $.each(attachments, function(i, att){
                    // Avoid duplicates
                    if( $('input[name="cec_flyer_ids[]"][value="'+att.id+'"]').length ) return;
                    var thumb = att.sizes && att.sizes.thumbnail ? att.sizes.thumbnail.url : '';
                    var isImage = att.type === 'image';
                    var preview = isImage && thumb
                        ? '<img src="'+thumb+'" alt="" />'
                        : '<span class="cec-file-icon">📄</span>';
                    var row = '<div class="cec-extra-flyer-item" data-id="'+att.id+'">'
                        + preview
                        + '<span class="cec-extra-flyer-name">'+att.filename+'</span>'
                        + '<input type="hidden" name="cec_flyer_ids[]" value="'+att.id+'" />'
                        + '<button type="button" class="button cec-remove-sidebar-flyer">Remove</button>'
                        + '</div>';
                    $('#cec-flyer-list').append(row);
                });
            });
            frame.open();
        });

        $(document).on('click', '.cec-remove-sidebar-flyer', function(){
            $(this).closest('.cec-extra-flyer-item').remove();
        });

        // ── Extra Flyers Upload ────────────────────────────────
        $('#cec-add-extra-flyer').on('click', function(e){
            e.preventDefault();
            var frame = wp.media({
                title: 'Select Flyer or Image',
                button: { text: 'Add to Event' },
                multiple: true
            });
            frame.on('select', function(){
                var attachments = frame.state().get('selection').toJSON();
                $.each(attachments, function(i, att){
                    // Avoid duplicates
                    if( $('input[name="cec_extra_flyer_ids[]"][value="'+att.id+'"]').length ) return;
                    var thumb = att.sizes && att.sizes.thumbnail ? att.sizes.thumbnail.url : '';
                    var isImage = att.type === 'image';
                    var preview = isImage && thumb
                        ? '<img src="'+thumb+'" alt="" />'
                        : '<span class="cec-file-icon">📄</span>';
                    var row = '<div class="cec-extra-flyer-item" data-id="'+att.id+'">'
                        + preview
                        + '<span class="cec-extra-flyer-name">'+att.filename+'</span>'
                        + '<input type="hidden" name="cec_extra_flyer_ids[]" value="'+att.id+'" />'
                        + '<button type="button" class="button cec-remove-extra-flyer">Remove</button>'
                        + '</div>';
                    $('#cec-extra-flyers-list').append(row);
                });
            });
            frame.open();
        });

        $(document).on('click', '.cec-remove-extra-flyer', function(){
            $(this).closest('.cec-extra-flyer-item').remove();
        });

    });

})(jQuery);
