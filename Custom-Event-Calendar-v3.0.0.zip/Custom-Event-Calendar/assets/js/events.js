/* Custom Event Calendar - Frontend JS | Version 3.0.0 | Cox Group */
(function($){
    'use strict';

    $(document).ready(function(){

        // ── Load More (legacy stub) ────────────────────────────
        var $btn = $('#cec-load-more');
        $btn.on('click', function(){
            var $self    = $(this);
            var page     = parseInt($self.data('page'));
            var perPage  = parseInt($self.data('per-page'));
            $self.text('Loading...').prop('disabled', true);
            $.ajax({
                url: cec_ajax.ajax_url,
                type: 'POST',
                data: { action: 'cec_load_more', nonce: cec_ajax.nonce, page: page, per_page: perPage },
                success: function(response){
                    if(response.success && response.data.html){
                        $('#cec-events-grid').append(response.data.html);
                        $self.data('page', response.data.page);
                        if(response.data.page >= response.data.max_pages){
                            $self.closest('.cec-load-more-wrap').fadeOut();
                        } else {
                            $self.text('Load More Events').prop('disabled', false);
                        }
                    } else {
                        $self.closest('.cec-load-more-wrap').fadeOut();
                    }
                },
                error: function(){ $self.text('Something went wrong. Try again.').prop('disabled', false); }
            });
        });

        // ── Lightbox ──────────────────────────────────────────
        $(document).on('click', '.cec-flyer-lightbox-trigger', function(e){
            e.preventDefault();
            var url = $(this).data('full-url');
            $('#cec-lightbox-img').attr('src', '').attr('src', url);
            $('#cec-lightbox').fadeIn(200);
            $('body').addClass('cec-lightbox-open');
        });

        $(document).on('click', '#cec-lightbox .cec-lightbox-backdrop, #cec-lightbox .cec-lightbox-close', function(){
            $('#cec-lightbox').fadeOut(200);
            $('body').removeClass('cec-lightbox-open');
        });

        $(document).on('keydown', function(e){
            if(e.key === 'Escape'){
                if($('#cec-lightbox').is(':visible')){
                    $('#cec-lightbox').fadeOut(200);
                    $('body').removeClass('cec-lightbox-open');
                }
                $('.cec-share-popup').prop('hidden', true);
                $('.cec-share-trigger').attr('aria-expanded', 'false');
            }
        });

        // ── Share Button ──────────────────────────────────────
        $(document).on('click', '.cec-share-trigger', function(e){
            e.stopPropagation();
            var $popup = $(this).siblings('.cec-share-popup');
            var isOpen = !$popup.prop('hidden');
            $('.cec-share-popup').prop('hidden', true);
            $('.cec-share-trigger').attr('aria-expanded', 'false');
            if(!isOpen){
                $popup.prop('hidden', false);
                $(this).attr('aria-expanded', 'true');
            }
        });

        $(document).on('click', function(e){
            if(!$(e.target).closest('.cec-share-wrap').length){
                $('.cec-share-popup').prop('hidden', true);
                $('.cec-share-trigger').attr('aria-expanded', 'false');
            }
        });

        // Copy link
        $(document).on('click', '.cec-share-copy-btn', function(e){
            e.preventDefault();
            var url    = $(this).data('url') || window.location.href;
            var $label = $(this).find('.cec-copy-label');
            if(navigator.clipboard && navigator.clipboard.writeText){
                navigator.clipboard.writeText(url).then(function(){
                    $label.text('Copied!');
                    setTimeout(function(){ $label.text('Copy Link'); }, 2000);
                });
            } else {
                var $tmp = $('<input>').val(url).appendTo('body').select();
                document.execCommand('copy');
                $tmp.remove();
                $label.text('Copied!');
                setTimeout(function(){ $label.text('Copy Link'); }, 2000);
            }
        });

        // ── Download All Flyers as PDF ─────────────────────────
        $('#cec-download-flyers-pdf').on('click', function(){
            var $dlBtn = $(this);
            $dlBtn.text('Generating PDF…').prop('disabled', true);

            var urls = [];
            $('.cec-flyer-lightbox-trigger').each(function(){
                var u = $(this).data('full-url');
                if(u) urls.push(u);
            });

            if(!urls.length){
                $dlBtn.text('Download All Flyers as PDF').prop('disabled', false);
                return;
            }

            var loaded = 0;
            var images = new Array(urls.length);

            $.each(urls, function(i, url){
                var img       = new Image();
                img.crossOrigin = 'anonymous';
                img.onload  = function(){ images[i] = img;  loaded++; if(loaded === urls.length){ buildPDF(images, $dlBtn); } };
                img.onerror = function(){ images[i] = null; loaded++; if(loaded === urls.length){ buildPDF(images, $dlBtn); } };
                img.src = url;
            });
        });

        function buildPDF(images, $dlBtn){
            var valid = images.filter(function(img){ return img && img.naturalWidth > 0; });

            if(!valid.length){
                alert('Could not load flyer images. Please try again.');
                $dlBtn.text('Download All Flyers as PDF').prop('disabled', false);
                return;
            }

            try {
                var jsPDF = (window.jspdf && window.jspdf.jsPDF) ? window.jspdf.jsPDF : window.jsPDF;
                if(!jsPDF){ throw new Error('jsPDF library not available'); }

                var first = valid[0];
                var doc   = new jsPDF({
                    orientation : first.naturalWidth >= first.naturalHeight ? 'l' : 'p',
                    unit        : 'px',
                    format      : [first.naturalWidth, first.naturalHeight],
                    hotfixes    : ['px_scaling']
                });

                $.each(valid, function(i, img){
                    var iw = img.naturalWidth;
                    var ih = img.naturalHeight;
                    if(i > 0){ doc.addPage([iw, ih], iw >= ih ? 'l' : 'p'); }
                    var canvas    = document.createElement('canvas');
                    canvas.width  = iw;
                    canvas.height = ih;
                    canvas.getContext('2d').drawImage(img, 0, 0);
                    doc.addImage(canvas.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, iw, ih);
                });

                doc.save('event-flyers.pdf');
            } catch(err){
                alert('PDF generation failed: ' + err.message);
            }

            $dlBtn.text('Download All Flyers as PDF').prop('disabled', false);
        }

    });

})(jQuery);
