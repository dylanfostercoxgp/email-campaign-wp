<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_filter( 'template_include', 'cec_template_loader' );
function cec_template_loader( $template ) {
    if ( is_singular( 'cec_event' ) ) {
        $custom = CEC_PLUGIN_DIR . 'templates/single-event.php';
        if ( file_exists( $custom ) ) {
            return $custom;
        }
    }
    return $template;
}
