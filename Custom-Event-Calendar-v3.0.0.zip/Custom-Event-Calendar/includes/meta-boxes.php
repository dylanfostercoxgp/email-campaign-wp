<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'add_meta_boxes', 'cec_add_meta_boxes' );
function cec_add_meta_boxes() {
    add_meta_box(
        'cec_event_details',
        'Event Details',
        'cec_render_event_details_meta_box',
        'cec_event',
        'normal',
        'high'
    );
    add_meta_box(
        'cec_event_pricing',
        'Pricing Tiers',
        'cec_render_pricing_meta_box',
        'cec_event',
        'normal',
        'default'
    );
    add_meta_box(
        'cec_event_extra_flyers',
        'Additional Flyers (Menu, Schedule, etc.)',
        'cec_render_extra_flyers_meta_box',
        'cec_event',
        'normal',
        'default'
    );
    add_meta_box(
        'cec_event_flyer',
        'Event Flyer',
        'cec_render_flyer_meta_box',
        'cec_event',
        'side',
        'default'
    );
}

// ── Event Details ──────────────────────────────────────────────
function cec_render_event_details_meta_box( $post ) {
    wp_nonce_field( 'cec_save_meta', 'cec_meta_nonce' );
    $start_date  = get_post_meta( $post->ID, '_cec_start_date', true );
    $start_time  = get_post_meta( $post->ID, '_cec_start_time', true );
    $end_date    = get_post_meta( $post->ID, '_cec_end_date', true );
    $end_time    = get_post_meta( $post->ID, '_cec_end_time', true );
    $location    = get_post_meta( $post->ID, '_cec_location', true );
    $subtitle    = get_post_meta( $post->ID, '_cec_subtitle', true );
    ?>
    <div class="cec-meta-grid">
        <div class="cec-meta-row">
            <label>Subtitle / Tagline</label>
            <input type="text" name="cec_subtitle" value="<?php echo esc_attr( $subtitle ); ?>" placeholder="e.g. Live music, dinner included" />
        </div>
        <div class="cec-meta-row cec-meta-half">
            <div>
                <label>Start Date <span class="required">*</span></label>
                <input type="date" name="cec_start_date" value="<?php echo esc_attr( $start_date ); ?>" />
            </div>
            <div>
                <label>Start Time</label>
                <input type="time" name="cec_start_time" value="<?php echo esc_attr( $start_time ); ?>" />
            </div>
        </div>
        <div class="cec-meta-row cec-meta-half">
            <div>
                <label>End Date</label>
                <input type="date" name="cec_end_date" value="<?php echo esc_attr( $end_date ); ?>" />
            </div>
            <div>
                <label>End Time</label>
                <input type="time" name="cec_end_time" value="<?php echo esc_attr( $end_time ); ?>" />
            </div>
        </div>
        <div class="cec-meta-row">
            <label>Location</label>
            <input type="text" name="cec_location" value="<?php echo esc_attr( $location ); ?>" placeholder="e.g. Main Pavilion, Saratoga Hot Springs Resort" />
        </div>
    </div>
    <?php
}

// ── Pricing ────────────────────────────────────────────────────
function cec_render_pricing_meta_box( $post ) {
    $pricing_tiers = get_post_meta( $post->ID, '_cec_pricing_tiers', true );
    if ( ! is_array( $pricing_tiers ) ) $pricing_tiers = array();
    ?>
    <p class="cec-meta-desc">Add one or more pricing tiers. Leave blank if this event is free or has no pricing.</p>
    <div id="cec-pricing-rows">
        <?php if ( ! empty( $pricing_tiers ) ) : ?>
            <?php foreach ( $pricing_tiers as $i => $tier ) : ?>
            <div class="cec-pricing-row">
                <input type="text" name="cec_pricing_label[]" value="<?php echo esc_attr( $tier['label'] ); ?>" placeholder="Label (e.g. General Admission)" />
                <input type="text" name="cec_pricing_price[]" value="<?php echo esc_attr( $tier['price'] ); ?>" placeholder="Price (e.g. $25)" />
                <button type="button" class="button cec-remove-row">Remove</button>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <button type="button" class="button" id="cec-add-pricing-row">+ Add Pricing Tier</button>
    <?php
}

// ── Extra Flyers ───────────────────────────────────────────────
function cec_render_extra_flyers_meta_box( $post ) {
    $extra_flyer_ids = get_post_meta( $post->ID, '_cec_extra_flyer_ids', true );
    if ( ! is_array( $extra_flyer_ids ) ) $extra_flyer_ids = array();
    ?>
    <p class="cec-meta-desc">Upload additional flyers such as menus, schedules, or sponsor pages. You can add multiple images or PDFs.</p>
    <div id="cec-extra-flyers-list">
        <?php foreach ( $extra_flyer_ids as $fid ) :
            $fid  = intval( $fid );
            $furl = wp_get_attachment_url( $fid );
            $fname = basename( get_attached_file( $fid ) );
            if ( ! $furl ) continue;
            $is_image  = wp_attachment_is_image( $fid );
            $thumb_url = $is_image ? wp_get_attachment_thumb_url( $fid ) : '';
        ?>
        <div class="cec-extra-flyer-item" data-id="<?php echo esc_attr( $fid ); ?>">
            <?php if ( $thumb_url ) : ?>
                <img src="<?php echo esc_url( $thumb_url ); ?>" alt="" />
            <?php else : ?>
                <span class="cec-file-icon">📄</span>
            <?php endif; ?>
            <span class="cec-extra-flyer-name"><?php echo esc_html( $fname ); ?></span>
            <input type="hidden" name="cec_extra_flyer_ids[]" value="<?php echo esc_attr( $fid ); ?>" />
            <button type="button" class="button cec-remove-extra-flyer">Remove</button>
        </div>
        <?php endforeach; ?>
    </div>
    <button type="button" class="button button-secondary" id="cec-add-extra-flyer">+ Add Flyer / Image</button>
    <?php
}

// ── Flyer (multiple) ───────────────────────────────────────────
function cec_render_flyer_meta_box( $post ) {
    // Read new multi-flyer array
    $flyer_ids = get_post_meta( $post->ID, '_cec_flyer_ids', true );
    if ( ! is_array( $flyer_ids ) ) $flyer_ids = array();

    // Backward compat: if old single _cec_flyer_id exists and not yet migrated, prepend it
    $legacy_id = intval( get_post_meta( $post->ID, '_cec_flyer_id', true ) );
    if ( $legacy_id && ! in_array( $legacy_id, array_map( 'intval', $flyer_ids ) ) ) {
        array_unshift( $flyer_ids, $legacy_id );
    }
    ?>
    <p class="cec-meta-desc">Upload one or more event flyers. Displayed prominently on the event page.</p>
    <div id="cec-flyer-list">
        <?php foreach ( $flyer_ids as $fid ) :
            $fid  = intval( $fid );
            $furl = wp_get_attachment_url( $fid );
            $fname = basename( get_attached_file( $fid ) );
            if ( ! $furl ) continue;
            $is_image  = wp_attachment_is_image( $fid );
            $thumb_url = $is_image ? wp_get_attachment_thumb_url( $fid ) : '';
        ?>
        <div class="cec-extra-flyer-item" data-id="<?php echo esc_attr( $fid ); ?>">
            <?php if ( $thumb_url ) : ?>
                <img src="<?php echo esc_url( $thumb_url ); ?>" alt="" />
            <?php else : ?>
                <span class="cec-file-icon">📄</span>
            <?php endif; ?>
            <span class="cec-extra-flyer-name"><?php echo esc_html( $fname ); ?></span>
            <input type="hidden" name="cec_flyer_ids[]" value="<?php echo esc_attr( $fid ); ?>" />
            <button type="button" class="button cec-remove-sidebar-flyer">Remove</button>
        </div>
        <?php endforeach; ?>
    </div>
    <button type="button" class="button button-secondary" id="cec-add-sidebar-flyer">+ Add Flyer</button>
    <?php
}

// ── Save Meta ──────────────────────────────────────────────────
add_action( 'save_post_cec_event', 'cec_save_meta' );
function cec_save_meta( $post_id ) {
    if ( ! isset( $_POST['cec_meta_nonce'] ) || ! wp_verify_nonce( $_POST['cec_meta_nonce'], 'cec_save_meta' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    $text_fields = array(
        'cec_start_date' => '_cec_start_date',
        'cec_start_time' => '_cec_start_time',
        'cec_end_date'   => '_cec_end_date',
        'cec_end_time'   => '_cec_end_time',
        'cec_location'   => '_cec_location',
        'cec_subtitle'   => '_cec_subtitle',
    );

    foreach ( $text_fields as $field => $meta_key ) {
        if ( isset( $_POST[ $field ] ) ) {
            update_post_meta( $post_id, $meta_key, sanitize_textarea_field( $_POST[ $field ] ) );
        }
    }

    // Sidebar flyers (multiple — new _cec_flyer_ids array)
    $sidebar_flyer_ids = array();
    if ( ! empty( $_POST['cec_flyer_ids'] ) && is_array( $_POST['cec_flyer_ids'] ) ) {
        foreach ( $_POST['cec_flyer_ids'] as $fid ) {
            $fid = intval( $fid );
            if ( $fid > 0 ) $sidebar_flyer_ids[] = $fid;
        }
    }
    update_post_meta( $post_id, '_cec_flyer_ids', $sidebar_flyer_ids );
    // Remove legacy single-flyer field now that it has been migrated into _cec_flyer_ids
    delete_post_meta( $post_id, '_cec_flyer_id' );

    // Extra flyers
    $extra_ids = array();
    if ( ! empty( $_POST['cec_extra_flyer_ids'] ) && is_array( $_POST['cec_extra_flyer_ids'] ) ) {
        foreach ( $_POST['cec_extra_flyer_ids'] as $fid ) {
            $fid = intval( $fid );
            if ( $fid > 0 ) $extra_ids[] = $fid;
        }
    }
    update_post_meta( $post_id, '_cec_extra_flyer_ids', $extra_ids );

    // Pricing tiers — save as clean indexed array, discard empty rows
    $tiers  = array();
    $labels = isset( $_POST['cec_pricing_label'] ) && is_array( $_POST['cec_pricing_label'] ) ? $_POST['cec_pricing_label'] : array();
    $prices = isset( $_POST['cec_pricing_price'] ) && is_array( $_POST['cec_pricing_price'] ) ? $_POST['cec_pricing_price'] : array();
    foreach ( $labels as $i => $label ) {
        $label = sanitize_text_field( trim( $label ) );
        $price = sanitize_text_field( trim( isset( $prices[ $i ] ) ? $prices[ $i ] : '' ) );
        if ( $label !== '' || $price !== '' ) {
            $tiers[] = array( 'label' => $label, 'price' => $price );
        }
    }
    // Delete first then re-add to avoid stale serialized data
    delete_post_meta( $post_id, '_cec_pricing_tiers' );
    if ( ! empty( $tiers ) ) {
        add_post_meta( $post_id, '_cec_pricing_tiers', $tiers );
    }
}
