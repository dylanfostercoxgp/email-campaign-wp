<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   [events_grid] — Full two-panel layout (agenda + card grid)
   ============================================================ */
add_shortcode( 'events_grid', 'cec_render_events_grid' );
function cec_render_events_grid( $atts ) {
    $today = date( 'Y-m-d' );

    $args = array(
        'post_type'      => 'cec_event',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'meta_key'       => '_cec_start_date',
        'orderby'        => 'meta_value',
        'order'          => 'ASC',
        'meta_query'     => array(
            array(
                'key'     => '_cec_start_date',
                'value'   => $today,
                'compare' => '>=',
                'type'    => 'DATE',
            ),
        ),
    );

    $query    = new WP_Query( $args );
    $post_ids = array();

    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) {
            $query->the_post();
            $post_ids[] = get_the_ID();
        }
        wp_reset_postdata();
    }

    ob_start();
    ?>
    <div class="cec-events-wrap">
        <?php if ( empty( $post_ids ) ) : ?>
            <p class="cec-no-events">No upcoming events at this time. Check back soon!</p>
        <?php else : ?>

        <div class="cec-events-page-layout">

            <aside class="cec-agenda-sidebar">
                <div class="cec-agenda-list">
                    <?php foreach ( $post_ids as $pid ) :
                        $start_date = get_post_meta( $pid, '_cec_start_date', true );
                        $start_time = get_post_meta( $pid, '_cec_start_time', true );
                        $permalink  = get_permalink( $pid );
                        $title      = get_the_title( $pid );
                        $ts         = $start_date ? strtotime( $start_date ) : 0;
                        $time_str   = '';
                        if ( $ts ) {
                            $time_str = date( 'M j', $ts );
                            if ( $start_time ) $time_str .= ' @ ' . date( 'g:ia', strtotime( $start_time ) );
                        }
                    ?>
                    <a href="<?php echo esc_url( $permalink ); ?>" class="cec-agenda-item">
                        <div class="cec-agenda-date-box">
                            <?php if ( $ts ) : ?>
                            <span class="cec-agenda-month"><?php echo date( 'M', $ts ); ?></span>
                            <span class="cec-agenda-day"><?php echo date( 'j', $ts ); ?></span>
                            <span class="cec-agenda-dow"><?php echo date( 'D', $ts ); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="cec-agenda-info">
                            <span class="cec-agenda-title"><?php echo esc_html( $title ); ?></span>
                            <?php if ( $time_str ) : ?>
                            <span class="cec-agenda-time">
                                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                                <?php echo esc_html( $time_str ); ?>
                            </span>
                            <?php endif; ?>
                        </div>
                        <span class="cec-agenda-arrow" aria-hidden="true">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg>
                        </span>
                    </a>
                    <?php endforeach; ?>
                </div>
            </aside>

            <div class="cec-events-grid-wrap">
                <div class="cec-events-grid" id="cec-events-grid">
                    <?php foreach ( $post_ids as $pid ) :
                        cec_render_event_card( $pid );
                    endforeach; ?>
                </div>
            </div>

        </div>

        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

/* ============================================================
   [events_agenda] — Standalone dark agenda list
   ============================================================ */
add_shortcode( 'events_agenda', 'cec_render_events_agenda' );
function cec_render_events_agenda( $atts ) {
    $atts  = shortcode_atts( array( 'limit' => -1 ), $atts, 'events_agenda' );
    $today = date( 'Y-m-d' );

    $args = array(
        'post_type'      => 'cec_event',
        'posts_per_page' => intval( $atts['limit'] ),
        'post_status'    => 'publish',
        'meta_key'       => '_cec_start_date',
        'orderby'        => 'meta_value',
        'order'          => 'ASC',
        'meta_query'     => array(
            array(
                'key'     => '_cec_start_date',
                'value'   => $today,
                'compare' => '>=',
                'type'    => 'DATE',
            ),
        ),
    );

    $query = new WP_Query( $args );
    ob_start();

    if ( ! $query->have_posts() ) {
        echo '<p class="cec-no-events">No upcoming events at this time. Check back soon!</p>';
    } else { ?>
        <div class="cec-agenda-sidebar cec-agenda-standalone">
            <div class="cec-agenda-list">
                <?php while ( $query->have_posts() ) :
                    $query->the_post();
                    $pid        = get_the_ID();
                    $start_date = get_post_meta( $pid, '_cec_start_date', true );
                    $start_time = get_post_meta( $pid, '_cec_start_time', true );
                    $ts         = $start_date ? strtotime( $start_date ) : 0;
                    $time_str   = '';
                    if ( $ts ) {
                        $time_str = date( 'M j', $ts );
                        if ( $start_time ) $time_str .= ' @ ' . date( 'g:ia', strtotime( $start_time ) );
                    }
                ?>
                <a href="<?php echo esc_url( get_permalink() ); ?>" class="cec-agenda-item">
                    <div class="cec-agenda-date-box">
                        <?php if ( $ts ) : ?>
                        <span class="cec-agenda-month"><?php echo date( 'M', $ts ); ?></span>
                        <span class="cec-agenda-day"><?php echo date( 'j', $ts ); ?></span>
                        <span class="cec-agenda-dow"><?php echo date( 'D', $ts ); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="cec-agenda-info">
                        <span class="cec-agenda-title"><?php the_title(); ?></span>
                        <?php if ( $time_str ) : ?>
                        <span class="cec-agenda-time">
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                            <?php echo esc_html( $time_str ); ?>
                        </span>
                        <?php endif; ?>
                    </div>
                    <span class="cec-agenda-arrow" aria-hidden="true">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg>
                    </span>
                </a>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        </div>
    <?php }

    return ob_get_clean();
}

/* ============================================================
   Shared card renderer
   ============================================================ */
function cec_render_event_card( $post_id ) {
    $start_date   = get_post_meta( $post_id, '_cec_start_date', true );
    $start_time   = get_post_meta( $post_id, '_cec_start_time', true );
    $permalink    = get_permalink( $post_id );
    $title        = get_the_title( $post_id );
    $date_display = '';

    if ( $start_date ) {
        $ts           = strtotime( $start_date );
        $date_display = date( 'F j, Y', $ts );
        if ( $start_time ) $date_display .= ' · ' . date( 'g:i A', strtotime( $start_time ) );
    }

    $thumb = get_the_post_thumbnail_url( $post_id, 'medium_large' );
    ?>
    <a href="<?php echo esc_url( $permalink ); ?>" class="cec-event-card">
        <div class="cec-card-image">
            <?php if ( $thumb ) : ?>
                <img src="<?php echo esc_url( $thumb ); ?>" alt="<?php echo esc_attr( $title ); ?>" loading="lazy" />
            <?php else : ?>
                <div class="cec-card-image-placeholder">
                    <span><?php echo esc_html( $start_date ? date( 'M', strtotime( $start_date ) ) : '' ); ?></span>
                </div>
            <?php endif; ?>
            <?php if ( $start_date ) : ?>
            <div class="cec-card-date-badge">
                <span class="cec-badge-month"><?php echo date( 'M', strtotime( $start_date ) ); ?></span>
                <span class="cec-badge-day"><?php echo date( 'j', strtotime( $start_date ) ); ?></span>
            </div>
            <?php endif; ?>
        </div>
        <div class="cec-card-body">
            <h3 class="cec-card-title"><?php echo esc_html( $title ); ?></h3>
            <?php if ( $date_display ) : ?>
                <p class="cec-card-date"><?php echo esc_html( $date_display ); ?></p>
            <?php endif; ?>
            <span class="cec-card-link">View Details &rarr;</span>
        </div>
    </a>
    <?php
}

// AJAX stub for backward compatibility
add_action( 'wp_ajax_cec_load_more', 'cec_ajax_load_more' );
add_action( 'wp_ajax_nopriv_cec_load_more', 'cec_ajax_load_more' );
function cec_ajax_load_more() {
    check_ajax_referer( 'cec_load_more', 'nonce' );
    wp_send_json_success( array( 'html' => '', 'page' => 1, 'max_pages' => 1 ) );
}
