<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'init', 'cec_register_post_type' );
function cec_register_post_type() {
    $labels = array(
        'name'               => 'Events',
        'singular_name'      => 'Event',
        'menu_name'          => 'Events',
        'add_new'            => 'Add New Event',
        'add_new_item'       => 'Add New Event',
        'edit_item'          => 'Edit Event',
        'new_item'           => 'New Event',
        'view_item'          => 'View Event',
        'search_items'       => 'Search Events',
        'not_found'          => 'No events found',
        'not_found_in_trash' => 'No events found in Trash',
        'all_items'          => 'All Events',
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'has_archive'        => false,
        'rewrite'            => array( 'slug' => 'events' ),
        'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'show_in_menu'       => true,
        'menu_icon'          => 'dashicons-calendar-alt',
        'menu_position'      => 5,
        'show_in_rest'       => true,
    );

    register_post_type( 'cec_event', $args );
}
