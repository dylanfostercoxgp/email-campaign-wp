<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function cec_get_calendar_links( $post_id ) {
    $start_date = get_post_meta( $post_id, '_cec_start_date', true );
    $start_time = get_post_meta( $post_id, '_cec_start_time', true );
    $end_date   = get_post_meta( $post_id, '_cec_end_date', true );
    $end_time   = get_post_meta( $post_id, '_cec_end_time', true );
    $location   = get_post_meta( $post_id, '_cec_location', true );
    $title      = get_the_title( $post_id );
    $url        = get_permalink( $post_id );

    if ( ! $start_date ) return array();

    // Build datetime strings
    $start_dt = $start_date . ( $start_time ? 'T' . str_replace( ':', '', $start_time ) . '00' : '' );
    $end_dt   = $end_date   ? $end_date . ( $end_time ? 'T' . str_replace( ':', '', $end_time ) . '00' : '' ) : $start_dt;

    // For Google: format YYYYMMDDTHHMMSS
    $g_start = str_replace( '-', '', $start_dt );
    $g_end   = str_replace( '-', '', $end_dt );
    if ( ! $start_time ) {
        // All-day event for Google
        $g_start = str_replace( '-', '', $start_date );
        $g_end   = str_replace( '-', '', ( $end_date ?: $start_date ) );
    }

    $details = 'More info: ' . $url;

    // Google Calendar
    $google_url = add_query_arg( array(
        'action'   => 'TEMPLATE',
        'text'     => rawurlencode( $title ),
        'dates'    => $g_start . '/' . $g_end,
        'details'  => rawurlencode( $details ),
        'location' => rawurlencode( $location ),
    ), 'https://calendar.google.com/calendar/render' );

    // iCal content (Apple + Outlook)
    $ical_start = $start_time ? str_replace( array( '-', ':' ), '', $start_date ) . 'T' . str_replace( ':', '', $start_time ) . '00' : str_replace( '-', '', $start_date );
    $ical_end   = $end_date
        ? ( $end_time ? str_replace( array( '-', ':' ), '', $end_date ) . 'T' . str_replace( ':', '', $end_time ) . '00' : str_replace( '-', '', $end_date ) )
        : $ical_start;

    return array(
        'google'  => esc_url( $google_url ),
        'ical_start' => $ical_start,
        'ical_end'   => $ical_end,
        'title'      => $title,
        'location'   => $location,
        'details'    => $details,
        'post_id'    => $post_id,
    );
}

// AJAX: Download .ics file
add_action( 'wp_ajax_cec_download_ics', 'cec_download_ics' );
add_action( 'wp_ajax_nopriv_cec_download_ics', 'cec_download_ics' );
function cec_download_ics() {
    $post_id = intval( $_GET['event_id'] ?? 0 );
    if ( ! $post_id ) wp_die( 'Invalid event.' );

    $links = cec_get_calendar_links( $post_id );
    if ( empty( $links ) ) wp_die( 'No date set for this event.' );

    $uid      = $post_id . '@' . parse_url( home_url(), PHP_URL_HOST );
    $now      = gmdate( 'Ymd\THis\Z' );
    $title    = $links['title'];
    $location = $links['location'];
    $details  = $links['details'];
    $start    = $links['ical_start'];
    $end      = $links['ical_end'];

    $ics = "BEGIN:VCALENDAR\r\n";
    $ics .= "VERSION:2.0\r\n";
    $ics .= "PRODID:-//Cox Group//Custom Event Calendar//EN\r\n";
    $ics .= "CALSCALE:GREGORIAN\r\n";
    $ics .= "METHOD:PUBLISH\r\n";
    $ics .= "BEGIN:VEVENT\r\n";
    $ics .= "UID:{$uid}\r\n";
    $ics .= "DTSTAMP:{$now}\r\n";
    $ics .= "DTSTART:{$start}\r\n";
    $ics .= "DTEND:{$end}\r\n";
    $ics .= "SUMMARY:" . cec_ics_escape( $title ) . "\r\n";
    $ics .= "LOCATION:" . cec_ics_escape( $location ) . "\r\n";
    $ics .= "DESCRIPTION:" . cec_ics_escape( $details ) . "\r\n";
    $ics .= "END:VEVENT\r\n";
    $ics .= "END:VCALENDAR\r\n";

    $filename = sanitize_title( $title ) . '.ics';
    header( 'Content-Type: text/calendar; charset=utf-8' );
    header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
    header( 'Cache-Control: no-cache, must-revalidate' );
    echo $ics;
    exit;
}

function cec_ics_escape( $string ) {
    return addcslashes( wp_strip_all_tags( $string ), ",;\\n" );
}
